import { getStore } from "@netlify/blobs";

const headers = { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" };
function json(data, status = 200) { return new Response(JSON.stringify(data), { status, headers }); }

async function authenticatedUser(request) {
  const authorization = request.headers.get("authorization") || "";
  const token = authorization.startsWith("Bearer ") ? authorization.slice(7) : "";
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_ANON_KEY;
  if (!token || !url || !key) return null;
  const response = await fetch(`${url.replace(/\/$/, "")}/auth/v1/user`, {
    headers: { apikey: key, Authorization: `Bearer ${token}` }
  });
  if (!response.ok) return null;
  return await response.json();
}

function validItem(item) {
  return item && typeof item === "object" && typeof item.id === "string" && item.id.length > 0 && item.id.length <= 100 &&
    typeof item.name === "string" && item.name.trim().length > 0 && item.name.length <= 70 &&
    (item.price === null || item.price === "" || (typeof item.price === "number" && Number.isFinite(item.price) && item.price >= 0));
}

export default async (request) => {
  try {
    const store = getStore("jmk-price-catalog");
    const url = new URL(request.url);
    if (request.method === "GET") {
      const listing = await store.list({ prefix: "items/" });
      const records = await Promise.all(listing.blobs.map(async ({ key }) => store.get(key, { type: "json" })));
      const items = records.filter(Boolean);
      items.sort((a, b) => String(a.name).localeCompare(String(b.name), "es"));
      return json({ items });
    }

    const user = await authenticatedUser(request);
    if (!user?.id) return json({ error: "Iniciá sesión para publicar o modificar tus avisos" }, 401);

    if (request.method === "PUT") {
      const body = await request.json();
      const item = body?.item;
      if (!validItem(item)) return json({ error: "Datos del ítem inválidos" }, 400);
      const key = `items/${item.id}`;
      const existing = await store.get(key, { type: "json" });
      if (existing?.sellerId && existing.sellerId !== user.id) return json({ error: "Solo el vendedor puede modificar esta publicación" }, 403);
      const metadataName = user.user_metadata?.display_name || user.email?.split("@")[0] || "Vendedor";
      const record = {
        ...item,
        sellerId: user.id,
        sellerName: existing?.sellerName || metadataName,
        name: item.name.trim(),
        status: item.status === "Vendido" ? "Vendido" : "Vendo",
        excellentOptions: Array.isArray(item.excellentOptions) ? item.excellentOptions.slice(0, 6) : [],
        createdAt: existing?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      await store.setJSON(key, record);
      return json({ ok: true, item: record });
    }

    if (request.method === "DELETE") {
      const id = url.searchParams.get("id");
      if (!id || id.length > 100) return json({ error: "Falta el ID del ítem" }, 400);
      const key = `items/${id}`;
      const existing = await store.get(key, { type: "json" });
      if (!existing) return json({ ok: true });
      if (existing.sellerId && existing.sellerId !== user.id) return json({ error: "Solo el vendedor puede eliminar esta publicación" }, 403);
      await store.delete(key);
      return json({ ok: true });
    }
    return json({ error: "Método no permitido" }, 405);
  } catch (error) {
    console.error("JMK PRICE storage error:", error);
    return json({ error: "No se pudo acceder al mercado compartido" }, 500);
  }
};
